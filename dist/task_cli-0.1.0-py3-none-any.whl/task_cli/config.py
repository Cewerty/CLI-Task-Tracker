config = {
    'path': r'src\data\data.json'
}